#!/usr/bin/env python

from setuptools import setup

setup(
    version="1.0.2",
    zip_safe=False,
    packages=['libindic.payyans'],
    namespace_packages=['libindic']
)
