#! /usr/bin/env python
# -*- coding: utf-8 -*-
__all__ = ["Payyans", "getInstance"]
from .core import Payyans, getInstance
